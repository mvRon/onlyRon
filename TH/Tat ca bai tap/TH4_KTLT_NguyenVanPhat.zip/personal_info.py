def show_id():
    print("ID: 2274802010636")
    Nhap()


def show_name():
    print("Name: Nguyen Van Phat")
    Nhap()

def show_class():
    print("Class: K28CNTT27")
    Nhap()

def show_email():
    print("Email: ronm250304@gmail.com")
    Nhap()



def Nhap():
    a = input("Nhap:")