import personal_info 

if __name__ == "__main__":
    personal_info.show_class()
    personal_info.show_email()
    personal_info.show_id()
    personal_info.show_name