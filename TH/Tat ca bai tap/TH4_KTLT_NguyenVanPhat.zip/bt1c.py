import personal_info as pi

if __name__ == "__main__":
    pi.show_class()
    pi.show_email()
    pi.show_id()
    pi.show_name