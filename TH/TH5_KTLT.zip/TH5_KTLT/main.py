# def math():
#     from packet import math_support
#     a = input("Nhap so thu nhat:")
#     b = input("Nhap so thu hai:")
#     c = input("Nhap so thu ba:")
#     return [math_support.bt_1(a,b,c), math_support.bt_2(a,b,c), math_support.bt_3(a,b,c)]


                

        

def date():
    from packet import date_support
    return [date_support.bt_567(), date_support.bt_9()]


def os():
    from packet import os_support
    return [os_support.bt16(), os_support.bt17()]


def string():
    from packet import string_support
    return [string_support.bt_10(), string_support.bt11(), string_support.bt12(), string_support.bt13(), string_support.bt14(), string_support.bt15()]


def b4():
    # b1, b2, b3, b4, b5, b6 = string()
    pass #dung tai day ngay 6.4

def choices(n):
    if n==1:
        pass
        # b1,b2,b3 = math() 
        # print(f"Tong 3 so: {b1}\nSo lon nhat: {b2}\nType: {b3}")
    elif n==2:
        b1, b2 = date()
        # print(type(b1)) 
        b1 = list(b1)
        print(f"{b2} {b1[1]}, {b1[2]}, {b1[2]}")
    elif n==3:
        b1, b2 = os()
        print(f"Host name: {b1}\nUser name: {b2}")
    elif n==4:
        b4()

    else:
        print("Lua chon ban nhap khong hop le!")




if __name__ == "__main__":
    print("phim 1: math_support!")
    print("phim 2: date_support!")
    print("phim 3: os_support!")
    print("phim 4: string_support!")
    n = int(input("Moi ban nhap lua chon:"))
    print("\n")
    choices(n)
