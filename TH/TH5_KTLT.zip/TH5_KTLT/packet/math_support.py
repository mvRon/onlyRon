def bt_1(a,b,c):
    result = ""
    try:
        a = float(a)
        b = float(b)
        c = float(c)
        if a!=[int,float]:
            result = str(a) + b + c
            return result
        elif b!=[float,int]:
            result = a + str(b) + c
            return result
        else:
            result = a + b + str(c)
            return result
    except:
        pass

# print(bt_1(a,b))


def bt_2(a, b, c):
    if (a>=b and a>=c):
        return a 
    elif (b>=a and b>=c):
        return b
    elif (c>=b and c>=a):
        return c
    else:
        pass
# print(bt_2(10 , 15, 40))


def bt_3(a,b,c):
    if type(a) and type(b) and type(c) in [int, float]:
        return 'Đây là số'
    return '1 trong 3 toán tử không phải là số'

# print(bt_3(3,4,5))