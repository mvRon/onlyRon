from personal_info import *

if __name__ == "__main__":
    show_id()
    show_class()
    show_email()
    show_class()
