import mathematic_helper as mt

if __name__ == "__main__":
    a = float(input("Nhap so A:"))
    b = float(input("Nhap so B:"))
    print(f"{a} + {b} = {mt.add(a,b)}")
    print(f"{a} - {b} = {mt.sub(a,b)}")
    print(f"{a} * {b} = {mt.mul(a,b)}")
    print(f"{a} / {b} = {mt.divide(a,b)}")
    print(f"{a}^2 = {mt.sqrt(a)}")



    


    